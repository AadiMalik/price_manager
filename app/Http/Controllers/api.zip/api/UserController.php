<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Product;
use App\WebSiteImage;
use App\SiteContent;
use App\Industry;
use App\City;
use App\UserType;
use App\RemarksImage;
use App\RemarksVideo;
use App\ConstructionVideo;
use App\UserPackage;
use App\ContactUs;
use Storage;
use File;

class UserController extends Controller
{
    public function indexAPI(Request $request)
    {
        if($request->token){
            $users = User::where('token', $request->token)->first();
            return response()->json($users);
        }else{
            return response()->json('Login First!');
        }
        
    }
    
    public function storeAPI(Request $request)
    {
        
            $user = new User;
            $user->name = $request->name;
            $user->email = $request->email;
            $user->status = 1;
            $user->phone_no = $request->phone_no;
            $user->user_type = $request->user_type;
            $user->token = md5($request->name);
            $user->password = Hash::make($request->password);
            $user->password_without_hash = $request->password;
            $result = $user->save();
            if(!$result){
                return response()->json('0');
            }else{
                return response()->json($user);
            }   
    }
    
    public function loginAPI(Request $request)
    {
        $users = User::where('email', $request->email)->first();
        
        if($users!=null){
            if(Hash::check($request->password, $users->password)){
            return response()->json($users);
        }else{
            return response()->json('Password is Invalid');
        }
        }else{
            return response()->json('Email is Invalid');
        }
        
        
    }
    public function profileAPI(Request $request)
    {
        

        // $validation=$request->validate([
        //     'first_name' => 'required|max:50|min:1',
        //     'last_name' => 'required|max:50|min:1',
        //     'address' => 'required|max:100|min:3',
        //     'city' => 'required',
        //     'description' => 'required',
        //     'description' => 'required|max:450|min:3'
        // ]);
        if($request->token){
            $check= User::where('token', $request->token)->first();
            $user = User::find($check->id);
            $user->first_name = $request->first_name;
            $user->last_name = $request->last_name;
            $user->address = $request->address;
            $user->city_id = $request->city;
            if ($request->has('image')) {
                if ($user->image_url) {
                    Storage::delete($user->image_url);
                }
                $fileFolder = 'userProfile';
//
                if (!Storage::exists($fileFolder)) {
                    Storage::makeDirectory($fileFolder);
                }

                $imageUrl = Storage::disk('public')->putFile($fileFolder, $request->image);
                $user->image_url = 'app/public/'.$imageUrl;
            }
            $user->description = $request->description;
            $result = $user->update();
            if($result){
                return response()->json('1');
            }else{
                return response()->json('0');
            }
            
        }else{
            return response()->json('Login First!');
        }
    }
    public function passwordAPI(Request $request)
    {
        
        $check= User::where('token', $request->token)->first();
        
        if($check!=null){
            if($request->password == $request->confirm_password){
                $users = User::find($check->id);
                $users->password = Hash::make($request->password);
                $users->password_without_hash = $request->password;
                $users->update();
                return response()->json('Password is Updated');
            }else{
                return response()->json('Password dos not Match!');
            }
        }else{
            return response()->json('Please Login First');
        }
        
        
    }
    public function product(Request $request)
    {
        $users = User::where('token', $request->token)->first();
        $product = Product::where('user_id', $users->id)->get();
        return response()->json($product);
    }
    public function productEdit(Request $request)
    {
        $product = Product::where('id', $request->id)->first();
        return response()->json($product);
    }
    public function productUpdate(Request $request)
    {
        // $data = [
            
        //     'name' => ucwords($request->name),
        //     'price' => $request->price,
        //     'quality' => $request->quality,
        //     'size' => $request->size,
        //     'description' => $request->description,
        // ];

        if ($request->has('image')) {
            $fileFolder = 'userProduct';
//
            if (!Storage::exists($fileFolder)) {
                Storage::makeDirectory($fileFolder);
            }
            

            $imageUrl = Storage::disk('public')->putFile($fileFolder, $request->image);
            $data['image_url'] = $imageUrl;
        }
        $product = Product::find($request->id);
        if($product){
            $product->update($data);
            return response()->json('Product is Updated!');
        }
           
    }
    public function Slider()
    {
        $slider = WebSiteImage::all();
        return response()->json($slider);
    }
    public function Site_Content()
    {
        $content = SiteContent::all();
        return response()->json($content);
    }
    public function Industry()
    {
        $industry = Industry::all();
        return response()->json($industry);
    }
    public function User_type()
    {
        $user_type = UserType::all();
        return response()->json($user_type);
    }
    public function City()
    {
        $city = City::all();
        return response()->json($city);
    }

    public function Brand()
    {
        $brand = User::where('brand_id',1)->get();
        return response()->json($brand);
    }

    public function Construction()
    {
        $construction = ConstructionVideo::all();
        return response()->json($construction);
    }

    public function company(){
        $company = User::with('city', 'products','reviews')->where('user_type', '!=', 1)->where('user_type', '!=', 2)->whereHas('products', function($q)
    {
        $q->where('price','>', 0);
    })->get();

    return response()->json($company);
    }

    public function search(Request $request){
        $search = User::with('city', 'userRating', 'userType', 'products', 'userPackage' ,'reviews')->where('email', '!=', 'admin@gmail.com')->whereHas('products', function($q)
{
    $q->where('price','>', 1);

});
        if ($request->city) {
            if ($request->city != 'all') {
                $search->where('city_id', $request->city);
            }
        }

        if ($request->user_type) {
            if ($request->user_type != 'all') {
                $search->where('user_type', $request->user_type);
            };
        }

        if ($request->industry) {
            if ($request->industry != 'all') {
                $search->where('industry_id', $request->industry);
            };
        }

        $search = $search->get();

        return response()->json($search);
    }


    public function userDetail (Request $request) {
        $user = User::findOrFail($request->id);
        $user_detail = User::with('city', 'products','reviews')->where('id',$request->id)->whereHas('products', function($q)
        {
            $q->where('price','>', 0);
        })->get();

        return response()->json($user_detail);
        
    }

    public function userImageRemarks (Request $request) {
        $ImageRemarks = RemarksImage::where('user_id',$request->id)->get();

        return response()->json($ImageRemarks);
        
    }
    public function userVideoRemarks (Request $request) {
        $VideoRemarks = RemarksVideo::where('user_id',$request->id)->get();

        return response()->json($VideoRemarks);
        
    }

    public function VideoRemarks() {
        $Videos = RemarksVideo::all();

        return response()->json($Videos);
        
    }
    public function ImageRemarks() {
        $images = RemarksImage::all();

        return response()->json($images);
        
    }

    public function Packages() {
        $packages = UserPackage::all();

        return response()->json($packages);
        
    }

    public function storeContact (Request $request) {
        
            $contact = new ContactUs;
            $contact->name = $request->name;
            $contact->email = $request->email;
            $contact->subject = $request->subject;
            $contact->message = $request->message;
            $result = $contact->save();
            if(!$result){
                return response()->json('0');
            }else{
                return response()->json('1');
            }
            
        
    }
}
